# Custom files

You can put your custom files (inventory, extra variable files) here.

This directory is ignored from the git tree - only this README is known.
